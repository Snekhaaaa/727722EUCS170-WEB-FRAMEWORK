package com.example.qns3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Qns3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
